/*
    Author - HoverGuy
	© All Fucks Reserved
*/

/*
    Defines available shops and their content
*/
class HG_VehiclesShopCfg
{
	/* Used as a param for the call, basically the shop you want to display */
	class HG_DefaultShop
	{
		/* Shop type */
        class Civilian
	    {
			/* Shop display name */
	        displayName = "$STR_HG_SHOP_CIVILIAN";
			/* 
			    Shop content 
				0 - STRING - Classname
				1 - INTEGER - Price
			*/
		    vehicles[] =
		    {
		        {"CUP_C_Skoda_White_CIV",15000}
		    };
			/* 
			    Spawn pos (markers)
				0 - STRING - Marker display name
				1 - STRING - Marker name
			*/
			spawnPoints[] =
			{
				{"$STR_HG_MARKER_1","civilian_vehicles_spawn"}
			};
	    };
	
	    class Military
	    {
	        displayName = "$STR_HG_SHOP_MILITARY";
		    vehicles[] =
		    {
		        {"CUP_C_Datsun_Plain",20000}
		    };
			spawnPoints[] =
			{
				{"$STR_HG_MARKER_2","military_vehicles_spawn"}
			};
	    };
	};
	
	/* 
	----------
	Here you can setup your own shop following the same format as the one just above
	----------
	*/
};

class HG_WeaponsShopCfg
{
	/* Used as a param for the call, basically the shop you want to display */
	class HG_DefaultShop
	{
		/* Shop type */
        class Weapons
	    {
			/* Shop display name */
	        displayName = "$STR_HG_SHOP_WEAPONS";
			/* 
			    Shop content 
				0 - STRING - Classname
				1 - INTEGER - Price
			*/
		    items[] =
		    {
		        {"arifle_MXC_F",12000},
                {"arifle_MXM_F",13000},
                {"hgun_P07_F",1500}
		    };
	    };
	
	    class Items
	    {
	        displayName = "$STR_HG_SHOP_ITEMS";
		    items[] =
		    {
		        {"ItemWatch",50},
			    {"ItemCompass",50},
			    {"ItemGPS",50},
			    {"ItemRadio",50},
			    {"ItemMap",50}
		    };
	    };
	
	    class Magazines
	    {
	        displayName = "$STR_HG_SHOP_MAGAZINES";
		    items[] =
		    {
		        {"30Rnd_65x39_caseless_mag",250},
                {"16Rnd_9x21_Mag",75},
	            {"30Rnd_9x21_Mag",150}
		    };
	    };
	
	    class Scopes
	    {
	        displayName = "$STR_HG_SHOP_SCOPES";
		    items[] =
		    {
		        {"optic_Arco",1000},
			    {"optic_Hamr",1000}
		    };
	    };
	};
	
	/* 
	----------
	Here you can setup your own shop following the same format as the one just above
	----------
	*/
};

class HG_ClothingShopCfg
{
	/* Used as a param for the call, basically the shop you want to display */
	class HG_DefaultShop
	{
		/* Shop type */
		class Facewear
		{
			/* Shop display name */
			displayName = "$STR_HG_SHOP_FACEWEAR";
			/* 
			    Shop type - Used for the camera positioning - MANDATORY
				You can add more camera positions this way (see fn_setCamPos.sqf)
				0 = Headgear / Facewear
				1 = Backpack
				2 = Uniform / Vest
			*/
			type = 0;
			/* 
			    Shop content 
				0 - STRING - Classname
				1 - INTEGER - Price
			*/
			content[] =
			{
				{"G_Balaclava_blk",50},
				{"G_Bandanna_shades",50},
				{"T_HoodBlkBLK",50},
				{"T_HoodODBLK",50},
				{"T_HoodTanBlk",50},
				{"Shemagh_FaceGry",50},
				{"Shemagh_FaceOD",50},
				{"Shemagh_FaceRed",50},
				{"Shemagh_FaceTan",50},
				{"Shemagh_Face",50},
				{"L_Shemagh_Gry",50},
				{"L_Shemagh_OD",50},
				{"G_Bandanna_aviator",50},
				{"CUP_TK_NeckScarf",50},
				{"Mask_M40",600},
				{"Mask_M40_OD",600}
			};
		};
		
		class Headgear
		{
			displayName = "$STR_HG_SHOP_HEADGEAR";
			type = 0;
			content[] =
			{
				{"H_Booniehat_khk",50},
				{"H_Booniehat_oli",50},
				{"H_Booniehat_grn",50},
				{"H_Booniehat_tan",50},
				{"H_Booniehat_dirty",50},
				{"H_Cap_red",50},
				{"H_Cap_blu",50},
				{"H_Cap_oli",50},
				{"H_Cap_tan",50},
				{"H_Cap_blk",50},
				{"H_Cap_grn",50},
				{"H_Cap_grn_BI",50},
				{"H_Bandanna_surfer",50},
				{"H_Bandanna_khk",50},
				{"H_StrawHat",50},
				{"H_StrawHat_dark",50},
				{"H_Hat_blue",50},
				{"H_Hat_brown",50},
				{"H_Hat_camo",50},
				{"H_Hat_grey",50},
				{"H_Hat_checker",50},
				{"H_Hat_tan",50},
				{"CUP_H_PMC_Cap_Back_Burberry",50},
				{"CUP_H_PMC_Cap_Back_Tan",50},
				{"CUP_H_NAPA_Fedora",50},
				{"CUP_H_C_MAGA_01",50},
				{"TRYK_H_Bandana_H",50}
			};
		};
		
		class Vests
	    {
	        displayName = "$STR_HG_SHOP_VESTS";
			type = 2;
		    content[] =
		    {
		        {"CUP_V_C_Police_Holster",100},
				{"CUP_V_O_TK_OfficerBelt",300},
				{"CUP_V_O_TK_OfficerBelt2",350},
				{"CUP_V_OI_TKI_Jacket1_04",500},
				{"CUP_V_OI_TKI_Jacket1_06",500},
				{"CUP_V_OI_TKI_Jacket1_05",500},
				{"V_RebreatherB",350}
		    };
	    };
		
        class Uniforms
	    {
	        displayName = "$STR_HG_SHOP_UNIFORMS";
			type = 2;
		    content[] =
		    {
		        {"U_C_Poloshirt_blue",150},
				{"U_C_Poloshirt_burgundy",150},
				{"U_C_Poloshirt_tricolour",150},
				{"U_C_Poloshirt_salmon",150},
				{"U_C_Poloshirt_redwhite",150},
				{"CUP_O_TKI_Khet_Jeans_04",150},
				{"CUP_O_TKI_Khet_Jeans_02",150},
				{"CUP_O_TKI_Khet_Jeans_01",150},
				{"CUP_U_C_Pilot_01",150},
				{"TRYK_shirts_DENIM_BK",150},
				{"TRYK_shirts_DENIM_BL",150},
				{"TRYK_shirts_DENIM_BWH",150},
				{"TRYK_shirts_DENIM_od",150},
				{"TRYK_shirts_DENIM_WHB",150},
				{"TRYK_shirts_DENIM_ylb",150},
				{"U_BG_Guerilla1_1",200},
				{"U_IG_Guerilla2_1",300},
				{"U_IG_Guerilla2_2",350},
				{"U_IG_Guerilla2_3",350},
				{"U_C_HunterBody_grn",350},
				{"U_IG_Guerilla3_1",350},
				{"U_I_G_resistanceLeader_F",300},
				{"U_B_Wetsuit",500}
		    };
	    };
		
		class Backpacks
		{
			displayName = "$STR_HG_SHOP_BACKPACKS";
			type = 1;
			content[] =
			{
				{"CUP_B_AlicePack_Khaki",800},
				{"B_mas_m_Bergen_al",900},
				{"CUP_B_AlicePack_Bedroll",950},
				{"CUP_B_HikingPack_Civ",800},
				{"CUP_B_CivPack_WDL",750},
				{"B_FieldPack_blk",700},
				{"B_FieldPack_cbr",700},
				{"B_FieldPack_oli",700},
				{"TRYK_B_FieldPack_Wood",700},
				{"CUP_B_SLA_Medicbag",300},
				{"TRYK_B_BAF_BAG_BLK",800},
				{"TRYK_B_BAF_BAG_rgr",800}
			};
		};
	};
	
	/* 
	----------
	Here you can setup your own shop following the same format as the one just above
	----------
	*/
};
